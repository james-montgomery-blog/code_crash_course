package com.example.nativeimport;
import java.util.ArrayList;

// https://www.programiz.com/java-programming/packages-import

public class NativeImport {
    public static void main(String[] args) {

        ArrayList<Integer> myList = new ArrayList<>(3);

        myList.add(3);
        myList.add(2);
        myList.add(1);

        System.out.println(myList);
    }
}




