package com.example.helloworld;

// https://www.jetbrains.com/help/idea/creating-and-running-your-first-java-application.html
// compile javac
// run java

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

    public static void import_test() {
        System.out.println("Hello World!");
    }
}
