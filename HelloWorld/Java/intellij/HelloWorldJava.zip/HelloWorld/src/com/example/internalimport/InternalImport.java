package com.example.internalimport;
import com.example.helloworld.HelloWorld;
//import com.example.helloworld.*;

public class InternalImport {
    public static void main(String[] args) {
        HelloWorld.import_test();
    }
}
