package com.example.helloworld

// compile scalac
// run scala

object HelloWorld extends App {
    println("Hello World!")
}

object HelloWorld2 {
 def main (args: Array[String]): Unit = {
   println("Hello World!")
 }

  def import_test (): Unit = {
    println("Hello World!")
  }
}