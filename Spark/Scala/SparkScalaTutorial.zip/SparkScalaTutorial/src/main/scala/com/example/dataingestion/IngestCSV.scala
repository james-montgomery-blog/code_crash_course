package com.example.dataingestion

import org.apache.spark.sql.SparkSession

// var = variable and val = immutable

object IngestCSV {

  def main(args: Array[String]) {

    val spark = SparkSession
      .builder()
      .appName("SparkSessionZipsExample")
      .master("local[*]").config("spark.driver.bindAddress", "127.0.0.1")
      .getOrCreate()

    val path = "/Users/jamesmontgomery/Desktop/data.csv"
    val df = spark.read.format("csv").option("header", "true").load(path)

    val df2 = df.select(
      df("Y")cast("float"),
      df("X").cast("float"),
      df("test_vs_train")
    )

    df2.show()

  }

}
